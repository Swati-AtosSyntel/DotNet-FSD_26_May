﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCApplication1.Models
{
    public class Employee
    {
        [Required(ErrorMessage = "Please enter your id")]
        [Display(Name ="Employee ID")]
        public int eid { get; set; }
        [Required]
        [Display(Name = "Employee Name")]
        public string ename { get; set; }
        [Required(ErrorMessage ="Please enter your name")]
        [Display(Name = "Work Location")]
        public string location { get; set; }
        [Required(ErrorMessage ="Please enter your work location")]
        [Display(Name = "Date Of Joining")]
        public string DOJ { get; set; }
        [Required(ErrorMessage ="Please enter your email address")]
        [EmailAddress(ErrorMessage ="Invalid Email Address")]
        [Display(Name = "Email Address")]
        public string Email { get; set; }

    }
}