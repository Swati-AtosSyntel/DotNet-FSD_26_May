﻿using MVCApplication1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCApplication1.Controllers
{
    public class EmpController : Controller
    {
        public static List<Employee> list=new List<Employee>();
        // GET: Emp
        public ActionResult Index()
        {
            return View(list);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Employee e)
        {
            if (ModelState.IsValid)
            {
                list.Add(e);
                return View("Index", list);
            }
            return View(e);
        }
        //[HttpPost]
        //public ActionResult Create(FormCollection form)
        //{
        //    Employee e = new Employee();
        //    e.eid = Convert.ToInt32(form["eid"]);
        //    e.ename = form["ename"];
        //    e.location = form["location"];
        //    e.Email = form["Email"];
        //    e.DOJ = form["DOJ"];
        //    list.Add(e);
        //    return View("Index",list);
        //}
        //[HttpPost]
        //public ActionResult Create(int id,string name,string location,string email,string date)
        //{
        //    Employee e = new Employee();
        //    e.eid = id;
        //    e.ename = name;
        //    e.location = location;
        //    e.Email = email;
        //    e.DOJ = date;
        //    list.Add(e);
        //    return View("Index", list);
        //}
    }
}