﻿using MVCApplication1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCApplication1.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            Employee e = new Employee()
            {
                eid = 123,
                ename = "Swati",
                location = "Pune",
                Email = "Swati.Bhirud@atos.net",
                DOJ = "15-Feb-2015"
            };
            //return View(e);
            ViewData["emp"] = e;
            ViewBag.employee = e;
            TempData["employee"] = e;
            // return View();
            return RedirectToAction("ShowEmployeeData");
        }
        public ActionResult ShowEmployeeData()
        {
            Employee employee;
            if (TempData.ContainsKey("employee"))
            {
                employee = TempData["employee"] as Employee;
                TempData.Keep("employee");
            }  

            return View();
        }
    }
}