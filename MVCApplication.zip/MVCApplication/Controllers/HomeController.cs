﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCApplication1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public string ShowMessage()
        {
            return "Welcome to ASP.NEt MVC";
        }
        public JsonResult ShowData()
        {
            return Json(new { id=123, name="Swati" }, JsonRequestBehavior.AllowGet);
        }
    }
}